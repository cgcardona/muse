"""Muse domain plugins."""
